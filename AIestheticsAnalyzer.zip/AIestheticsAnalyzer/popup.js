const activateButton = document.getElementById("activate");
const deactivateButton = document.getElementById("deactivate");

activateButton.addEventListener("click", () => {
  sendMessageToTab("activate");
  activateButton.style.display = "none";
  deactivateButton.style.display = "inline-block";
});

deactivateButton.addEventListener("click", () => {
  sendMessageToTab("deactivate");
  deactivateButton.style.display = "none";
  activateButton.style.display = "inline-block";
});

async function sendMessageToTab(action) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: action });
  } catch (error) {
    console.error(error.message);
  }
}
