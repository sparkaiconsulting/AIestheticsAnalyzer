if (!window.contentScriptInjected) {
  window.contentScriptInjected = true;

  let currentAction = null;
  let infoBox = null;

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "activate") {
      currentAction = "activate";
      document.body.style.cursor = "crosshair";
      document.body.addEventListener("mousemove", handleMouseMove);
      document.body.addEventListener("click", handleClick);
      createInfoBox();
    } else if (request.action === "deactivate") {
      currentAction = null;
      document.body.style.cursor = "";
      document.body.removeEventListener("mousemove", handleMouseMove);
      document.body.removeEventListener("click", handleClick);
      removeInfoBox();
    }
  });

  function createInfoBox() {
    if (!infoBox) {
      infoBox = document.createElement("div");
      infoBox.style.position = "fixed";
      infoBox.style.padding = "10px";
      infoBox.style.border = "1px solid #FF9F1C";
      infoBox.style.borderRadius = "5px";
      infoBox.style.backgroundColor = "#000000";
      infoBox.style.color = "#FF9F1C";
      infoBox.style.fontFamily = "Roboto Slab, sans-serif";
      infoBox.style.zIndex = "999999";
      infoBox.style.display = "none";
      document.body.appendChild(infoBox);
    }
  }

  function removeInfoBox() {
    if (infoBox) {
      infoBox.style.display = "none";
    }
  }

  function updateInfoBox(x, y, message) {
    if (infoBox) {
      infoBox.style.left = `${x + 15}px`;
      infoBox.style.top = `${y + 15}px`;
      infoBox.style.display = "block";
      infoBox.innerHTML = message;
    }
  }

async function handleMouseMove(event) {
  if (currentAction === "activate") {
    let style = window.getComputedStyle(event.target);
    let message = "";

    let backgroundColor = await getDominantColor(event.target);
    let fontColor = style.color;

    message += `<span style="color: #FF9F1C">BG Color:</span> <span style="color: #FFFFFF">${rgbToHex(backgroundColor)}</span><span style="color: #FFFFFF">, </span>`;
    message += `<span style="color: #FF9F1C">Font Color:</span> <span style="color: #FFFFFF">${rgbToHex(fontColor)}</span><br>`;

    if (event.target.textContent.trim().length > 0) {
      message += `<span style="color: #FF9F1C">Font Stack:</span> <span style="color: #FFFFFF">${style.fontFamily}</span><span style="color: #FFFFFF">, </span>`;
      message += `<span style="color: #FF9F1C">Size:</span> <span style="color: #FFFFFF">${style.fontSize}</span><span style="color: #FFFFFF">, </span>`;
      message += `<span style="color: #FF9F1C">Weight:</span> <span style="color: #FFFFFF">${style.fontWeight}</span>`;
    }

    updateInfoBox(event.pageX - window.pageXOffset, event.pageY - window.pageYOffset, message);
  }
}

  async function getDominantColor(element) {
    if (element.tagName === 'IMG') {
      return await getDominantColorFromImage(element);
    } else {
      return await getDominantColorFromBackground(element);
    }
  }

  async function getDominantColorFromImage(imgElement) {
    const colorThief = new ColorThief();
    const color = colorThief.getColor(imgElement);
            return color;
  }

async function getDominantColorFromBackground(element) {
  const style = window.getComputedStyle(element);
  return style.backgroundColor === 'rgba(0, 0, 0, 0)' ? getDominantColorFromParent(element) : style.backgroundColor;
}

function getDominantColorFromParent(element) {
  if (element.parentElement) {
    const parentStyle = window.getComputedStyle(element.parentElement);
    return parentStyle.backgroundColor === 'rgba(0, 0, 0, 0)' ? getDominantColorFromParent(element.parentElement) : parentStyle.backgroundColor;
  }
  return 'rgba(0, 0, 0, 0)';
}

  function rgbToHex(rgb) {
    if (typeof rgb === 'string') {
      let match = rgb.match(/\d+/g);
      if (match) {
        let [r, g, b] = match.map(Number);
        return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
      }
    } else if (Array.isArray(rgb)) {
      let [r, g, b] = rgb;
      return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
    }
    return 'unknown';
  }

  function handleClick(event) {
    if (currentAction === "activate") {
      event.preventDefault();
      event.stopImmediatePropagation();
      document.body.style.cursor = "";
      document.body.removeEventListener("mousemove", handleMouseMove);
      document.body.removeEventListener("click", handleClick);
      currentAction = null;
      removeInfoBox();
    }
  }
}
