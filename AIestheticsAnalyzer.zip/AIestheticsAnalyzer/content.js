if (!window.contentScriptInjected) {
  window.contentScriptInjected = true;

  let currentAction = null;
  let infoBox = null;

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "activate") {
      currentAction = "activate";
      document.body.style.cursor = "crosshair";
      document.body.addEventListener("mousemove", handleMouseMove);
      document.body.addEventListener("click", handleClick);
      createInfoBox();
    } else if (request.action === "deactivate") {
      currentAction = null;
      document.body.style.cursor = "";
      document.body.removeEventListener("mousemove", handleMouseMove);
      document.body.removeEventListener("click", handleClick);
      removeInfoBox();
    }
  });

  function createInfoBox() {
    if (!infoBox) {
      infoBox = document.createElement("div");
      infoBox.style.position = "fixed";
      infoBox.style.padding = "10px";
      infoBox.style.border = "1px solid #FF9F1C";
      infoBox.style.borderRadius = "5px";
      infoBox.style.backgroundColor = "#000000";
      infoBox.style.color = "#FF9F1C";
      infoBox.style.fontFamily = "Roboto Slab, sans-serif";
      infoBox.style.zIndex = "999999";
      infoBox.style.display = "none";
      document.body.appendChild(infoBox);
    }
  }

  function removeInfoBox() {
    if (infoBox) {
      infoBox.style.display = "none";
    }
  }

  function updateInfoBox(x, y, message) {
    if (infoBox) {
      infoBox.style.left = `${x + 15}px`;
      infoBox.style.top = `${y + 15}px`;
      infoBox.style.display = "block";
      infoBox.innerHTML = message;
    }
  }

  function handleMouseMove(event) {
    if (currentAction === "activate") {
      let style = window.getComputedStyle(event.target);
      let message = "";

      if (style.color || style.backgroundColor) {
        message = `Color: ${style.color}`;
      }

      if (event.target.textContent.trim().length > 0) {
        message += `, <span style="color: #FFFFFF">Font: ${style.fontFamily}, Size: ${style.fontSize}, Weight: ${style.fontWeight}</span>`;
      }

      updateInfoBox(event.pageX - window.pageXOffset, event.pageY - window.pageYOffset, message);
    }
  }

  function handleClick(event) {
    if (currentAction === "activate") {
      event.preventDefault();
      event.stopImmediatePropagation();
      document.body.style.cursor = "";
      document.body.removeEventListener("mousemove", handleMouseMove);
      document.body.removeEventListener("click", handleClick);
      currentAction = null;
      removeInfoBox();
    }
  }
}
