AIestheticsAnalyzer

AIestheticsAnalyzer is a browser extension developed by Spark AI Consulting that enables users to identify any font and pick any color from a web page.

Installation:

1. Download the .zip file of AIestheticsAnalyzer from the GitHub repository.
2. Unzip the file into a directory of your choice.
3. Open your browser and go to the Extensions page:
*For Chrome, go to chrome://extensions/
*For Edge, go to edge://extensions/
4. Turn on Developer mode in the top right corner of the page.
5. Click "Load unpacked" and select the directory where you unzipped the AIestheticsAnalyzer files.
6. AIestheticsAnalyzer should now be loaded and ready to use!

Usage:

-Click the AIestheticsAnalyzer icon in your browser toolbar and click 'Activate' to activate the extension.
-Move your cursor over any text or color on the page to view the font and color information in the info box.
-Click the AIestheticsAnalyzer icon again and click 'Deactivate' to deactivate the extension.

Contributing:

If you would like to contribute to AIestheticsAnalyzer, please submit a pull request on GitHub.

Privacy:

We take your privacy seriously. AIestheticsAnalyzer does not collect any personal data. For more information, please read our privacy policy.

License:

AIestheticsAnalyzer is released under the MIT License.