AIestheticsAnalyzer

AIestheticsAnalyzer is a browser extension developed by Spark AI Consulting that enables users to identify any font and pick any color from a web page.

Installation:

1. Download the .zip file of AIestheticsAnalyzer from the GitHub repository.
2. Unzip the file into a directory of your choice.
3. Open your browser and go to the Extensions page:
*For Chrome, go to chrome://extensions/
*For Edge, go to edge://extensions/
4. Turn on Developer mode in the top right corner of the page.
5. Click "Load unpacked" and select the directory where you unzipped the AIestheticsAnalyzer files.
6. AIestheticsAnalyzer should now be loaded and ready to use!

Usage:

-Click the AIestheticsAnalyzer icon in your browser toolbar and click 'Activate' to activate the extension.
-Move your cursor over any text or color on the page to view the font and color information in the info box.
-Click the AIestheticsAnalyzer icon again and click 'Deactivate' to deactivate the extension.

Using color-thief:

This extension uses the 'color-thief' JavaScript library, specifically the 'color-thief.min' JavaScript file to extract colors from images on the page. 'color-thief.min.js' is distributed under the Creative Commons Attribution 4.0 International License (CC BY 4.0). We have included information about the use of color-thief in this readme.txt file, which is compliant with the license terms. Please ensure that you comply with the license terms when using this library in your extension. To do so, include the license file in your extension's directory and provide attribution to the color-thief library in your code or documentation.

Contributing:

If you would like to contribute to AIestheticsAnalyzer, please submit a pull request on GitHub.

Privacy:

We take your privacy seriously. AIestheticsAnalyzer does not collect any personal data. For more information, please read our privacy policy.

License:

AIestheticsAnalyzer is released under the MIT License.